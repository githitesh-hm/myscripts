#!/bin/bash

threshould=80

Email="hiteshmore0706@gmail.com"

#GET DISK USAGE PERCENTAGE

usage=$(df / | grep total: |awk '{print 4}')

if [[ "$usage" -gt "$threshould" ]]
 then
    subject="Disk usage Alert:$(usage)%"
    body="Warning:disk usage has excceeded : ${threshould}%"
    echo "$body" | mail -s "$subject" "$Email"
fi

